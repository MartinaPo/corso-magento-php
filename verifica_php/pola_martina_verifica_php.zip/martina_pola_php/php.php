<?php 
    $conn = null;

function connetti(){
    global $conn;

    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "verificaphp";
    $conn = mysqli_connect($host, $username, $password, $dbname);

 return true;
}

//funzione selezione dei dipendenti da menù dropdown
function selezione(){
    global $conn;

    $query = "SELECT * FROM dipendenti";
    $result = mysqli_query($conn, $query);

    if (! $result){
        print ("Errore di query:" . mysqli_error($conn));
        return false;
    }
    return $result;
}

//funzione lettura dei dati di timbrature
function lettura(){
    global $conn;

    $id = "SELECT id FROM timbrature";
    $codice = "SELECT codice FROM timbrature";
    $timbrature = "SELECT timestamp FROM timbrature";

    $risulta = mysqli_query($conn, $id, $codice, $timbrature);

    // while ($risulta = mysql_fetch_array($id)) {
    //     print <<<EOD
    //     <td>$id</td>
    //     EOD;
    //     }

 }





