<?php
    $conn = null;

    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "verificaphp";

    $conn = new mysqli($host, $username, $password, $dbname);
    
    $salva = $_REQUEST['codice2'];

    if (! isset($salva)) {
        $sql = "INSERT INTO timbrature VALUES (NULL, NULL, 'timestamp')";
    }